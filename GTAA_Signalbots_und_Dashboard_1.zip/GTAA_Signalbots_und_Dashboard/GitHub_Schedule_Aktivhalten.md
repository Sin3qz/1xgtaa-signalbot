# GitHub-Actions dauerhaft aktiv halten (60-Tage-Deaktivierung umgehen)

**Problem:** GitHub deaktiviert `schedule`-Workflows nach **60 Tagen ohne Aktivität eines echten
Nutzer-Accounts**. Die täglichen Commits deiner Bots laufen unter `github-actions[bot]` mit dem
Standard-`GITHUB_TOKEN` — **die zählen NICHT** als Aktivität. Nach ~60 Tagen bekommst du eine Mail
„scheduled workflow disabled" und der Cron steht.

Zwei Lösungen. **Lösung A (PAT) ist die sauberste** — einmal einrichten, nie wieder anfassen.
**Lösung B (Keepalive-Action)** ist ohne Token, aber minimal weniger „unsichtbar".

Mach das in **jedem der drei Bot-Repos** (1xgtaa / levgtaa / reversegtaa). Der levSpyBits-Bot
hat dasselbe Thema — dort genauso.

---

## Lösung A — Personal Access Token (empfohlen, sauberste Lösung)

Der Trick: der tägliche Commit wird nicht mehr vom `github-actions[bot]`, sondern **in deinem Namen**
(über ein Fine-grained Personal Access Token) gepusht. Solche Commits zählen als Nutzer-Aktivität und
halten den Cron dauerhaft aktiv.

### Schritt 1 — Token erstellen
1. GitHub → rechts oben auf dein Profilbild → **Settings**.
2. Ganz unten links: **Developer settings**.
3. **Personal access tokens → Fine-grained tokens → Generate new token**.
4. Ausfüllen:
   - **Token name:** z.B. `gtaa-bots-push`
   - **Expiration:** 1 Jahr (oder „No expiration", wenn du es dir merkst; du musst es sonst
     jährlich erneuern).
   - **Repository access → Only select repositories** → deine drei Bot-Repos auswählen
     (1xgtaa-signalbot, levgtaa-signalbot, reversegtaa-signalbot). Später levspybits mit rein.
   - **Permissions → Repository permissions → Contents → Read and write.**
     (Nur „Contents" reicht — mehr braucht der Push nicht.)
5. **Generate token** → den langen `github_pat_…`-String **sofort kopieren** (er wird nur einmal
   angezeigt).

### Schritt 2 — Token als Secret in jedes Repo legen
Pro Repo: **Settings → Secrets and variables → Actions → New repository secret**
- **Name:** `PAT_PUSH`
- **Secret:** der kopierte `github_pat_…`-String
- **Add secret.**

### Schritt 3 — Workflow auf den Token umstellen
In `.github/workflows/notify.yaml` sind **zwei** kleine Änderungen nötig.

**(a)** Beim `checkout`-Schritt den Token mitgeben (damit der spätere Push ihn nutzt):
```yaml
      - uses: actions/checkout@v4
        with:
          token: ${{ secrets.PAT_PUSH }}
```

**(b)** Im „Commit and push"-Schritt als Autor DICH eintragen (nicht den Bot). Ersetze die
`git config`-Zeilen durch deinen Namen/deine (evtl. noreply-)Mail:
```yaml
      - name: Commit and push changes
        run: |
          git config --global user.name "Sin3qz"
          git config --global user.email "DEINE-EMAIL@example.com"
          git add .
          git diff --cached --quiet && echo "Nichts zu committen" && exit 0
          git commit -m "Update signals [ci skip]"
          git pull --rebase origin main
          git push origin main
```
Das war's. Ab jetzt sind die täglichen Commits „von dir" → der Cron bleibt dauerhaft aktiv.
(Läuft der Token ab, einfach einen neuen erzeugen und das `PAT_PUSH`-Secret aktualisieren.)

---

## Lösung B — Keepalive-Action (ohne Token)

Ein fertiger Marketplace-Step, der periodisch einen leeren „Aktiv"-Commit macht, wenn sich das Repo
60 Tage nicht gerührt hat. Kein Token nötig, aber der Bot bleibt formal der Committer.

In `.github/workflows/notify.yaml` **am Ende des `notify`-Jobs** (als letzter Step) einfügen:
```yaml
      - name: Keepalive (verhindert 60-Tage-Deaktivierung)
        uses: gautamkrishnar/keepalive-workflow@v2
```
Fertig. Der Step tut normalerweise nichts und wird nur alle paar Wochen aktiv. Wenn du die Version
pinnen willst, schau im Marketplace nach dem aktuellen Tag von `gautamkrishnar/keepalive-workflow`.

---

## Lösung C — Handbetrieb (Null Aufwand beim Einrichten)

Wenn du nichts am Code ändern willst: **einmal alle ~50 Tage** in jedem Repo unter
**Actions → (Workflow wählen) → „Run workflow"** einmal manuell starten (oder einen Mini-Commit
machen). Das reicht, um die 60-Tage-Uhr zurückzusetzen. Trag dir eine Kalender-Erinnerung ein.

---

**Empfehlung:** Lösung **A** einmal einrichten und Ruhe haben. Wenn dir das Token-Handling zu viel
ist, nimm **B**. **C** nur, wenn du es wirklich manuell magst.

Quellen: GitHub-Doku „Disabling and enabling a workflow" + die bekannte Einschränkung, dass
`GITHUB_TOKEN`-Commits die Inaktivitäts-Uhr nicht zurücksetzen
([GitHub Community #57858](https://github.com/orgs/community/discussions/57858),
[keepalive-workflow](https://github.com/gautamkrishnar/keepalive-workflow)).

**KEINE ANLAGEBERATUNG.**
