# GTAA Signal-Bots + Dashboard — Einrichtung (Discord / GitHub / ntfy)

**Stand 2026-09-21.** Was du wo einrichten musst, damit die drei neuen Bots
(1xGTAA, levGTAA, reverse-GTAA) und das gemeinsame Dashboard laufen. Der bestehende
**levSpyBits-Bot** (vormals „SpyTips-Cool" / 3xSpyTips+BTC) bleibt bis auf **eine** Datei unverändert.
Alle Infrastruktur-Bugfixes B1–B12/F1–F4 aus dem alten Chat sind eingebaut. **KEINE ANLAGEBERATUNG.**

**Finale Strategie-Kennzahlen** (Bot-Engine == verifizierter v6-Backtest, 0 Abweichung):

| Strategie | CAGR | Sortino | MaxDD | mm5 | schlecht. Jahr |
|---|---|---|---|---|---|
| 1xGTAA (defensiv) | 16,0 | 1,25 | −18,2 | 0,83 | −2,5 |
| levGTAA (offensiv, **+BTC 1x**, Äquivola) | 50,5 | 1,43 | −50,2 | 1,30 | −18,0 |
| reverse-GTAA (Sleeve, **Tilt 30/70, slotfloor**) | 35,7 | 1,11 | −44,4 | 0,91 | −27,0 |

Deine Dateien:
- `bots/1xgtaa-signalbot/` · `bots/levgtaa-signalbot/` · `bots/reversegtaa-signalbot/`
- `bots/levspybits-signalbot-UPDATE/` (nur die eine `constants.py`, 75/25)
- `gtaa-dashboard/` (neues Dashboard, alle 4 Strategien; `USER = "Sin3qz"` schon gesetzt)
- `GitHub_Schedule_Aktivhalten.md` (Schritt-für-Schritt: 60-Tage-Deaktivierung umgehen, PAT + Keepalive)
- `GTAA_1xGTAA_levGTAA_Report.pdf` (15 S.) · `GTAA_reverseGTAA_Report.pdf` (18 S., komplett neu)

---

## A) GitHub — pro Bot (3×)

Für **jedes** der drei Bot-Verzeichnisse:

1. **Neues, öffentliches Repo** anlegen. Empf. Namen: `1xgtaa-signalbot`, `levgtaa-signalbot`,
   `reversegtaa-signalbot` (public → Actions gratis, kein Geheimnis im Code).
2. **Alle Dateien am EXAKTEN Pfad** hochladen — besonders `.github/workflows/notify.yaml`
   (nicht `workflows/…`!) und die `.py`-Endungen (B12). Struktur:
   ```
   main.py  send_ntfy.py  .gitignore  README.md
   .github/workflows/notify.yaml
   strategies/__init__.py  constants.py  gtaa_botcore.py  runner.py
   ```
3. **Repo-Secrets** (Settings → Secrets and variables → Actions → New repository secret):
   - `DISCORD_WEBHOOK_URL` → Webhook des jeweiligen Discord-Kanals (s. B).
   - `NTFY_TOPIC` → langer, geheimer Topic-Name (s. D). **Pro Bot ein EIGENER Topic.**
   - `NTFY_SERVER` → nur falls eigener ntfy-Server (sonst weglassen).
4. **Schreibrechte für Actions (B8, kritisch):** Settings → Actions → General →
   **Workflow permissions → „Read and write permissions"** → Save.
5. **Actions aktivieren** (Tab „Actions" → enable) und einmal „Run workflow" testen.
   Danach Cron täglich **07:17 Berlin** (`17 5 * * *`).

Der erste Lauf baut die History neu auf und meldet **kein** falsches „BUY" (B5) — nur die Statusnachricht.

### ⚠️ Wichtig: GitHub deaktiviert `schedule` nach 60 Tagen — auch bei täglichem Bot-Commit!

Deine berechtigte Frage: Ja, die Deaktivierung greift **trotz** täglicher Actions-Läufe. GitHub zählt
für die 60-Tage-Regel **nur Aktivität eines echten Nutzer-Accounts**. Die täglichen Commits des Bots
laufen unter `github-actions[bot]` mit dem Standard-`GITHUB_TOKEN` — **die zählen NICHT** als
Repo-Aktivität (genau deshalb gibt es die vielen „keepalive"-Actions). Nach ~60 Tagen ohne echte
Nutzer-Aktivität wird der Cron stillgelegt (du bekommst eine Mail „scheduled workflow disabled").

**Gegenmittel — such dir eins aus:**
- **Einfachst:** alle ~50 Tage einmal manuell „Run workflow" klicken oder einen Mini-Commit machen.
- **Automatisch:** eine Keepalive-Action einbauen (z.B. `gautamkrishnar/keepalive-workflow`), die
  periodisch einen echten Commit erzeugt.
- **Sauberste Lösung:** den Push-Schritt mit einem **Personal Access Token** statt `GITHUB_TOKEN`
  committen lassen — PAT-Commits zählen als Nutzer-Aktivität und halten den Cron dauerhaft aktiv.

(Quellen: [GitHub Community #57858](https://github.com/orgs/community/discussions/57858),
[keepalive-workflow](https://github.com/gautamkrishnar/keepalive-workflow).)

---

## B) Discord — 3 neue Kanäle + Webhooks

1. **Drei neue Text-Kanäle** anlegen, z.B. `#1xgtaa`, `#levgtaa`, `#reversegtaa`
   (dein levSpyBits-Kanal bleibt).
2. Pro Kanal: **Kanal-Einstellungen → Integrationen → Webhooks → Neuer Webhook → URL kopieren.**
3. Jede URL als `DISCORD_WEBHOOK_URL`-Secret ins **passende** Bot-Repo (A.3).

**Was in welchem Kanal ankommt (die Signaltabelle ist jetzt eine saubere, monospaced Tabelle):**
- **1xGTAA**: **tägliche** Statusmeldung (Cooldown-Modell). Kopf 🟢/🔴/🔄 nur bei echtem Wechsel.
- **levGTAA** & **reverse-GTAA**: **tägliche** Statusmeldung. Am **Monats-Signaltag** zusätzlich eine
  ausdrückliche Monatsnachricht — auch **ohne** Wechsel („KEINE ÄNDERUNG zum Vormonat" + Top-2/Flop-2
  mit %-Gewichten); bei Wechsel BUY/SELL/SWITCH.

**Neu in den Nachrichten (alle Strategien):** die Signaltabelle nennt jetzt für die SMA-Filter die
**absoluten %-Werte** (kein Haken/Kreuz), zeigt **nur die Assets** (keine konkreten ETFs/ISINs mehr),
die gehaltenen oben (Allokation) und unten (Tabelle „HALT xx%"), und ist als Code-Block ausgerichtet.
Der Äquivola-/Produkt-**Hebel bleibt** bei levGTAA/reverse dran (z.B. „(3x)", „(1x)" bei BTC).

---

## C) Dashboard (neues Repo, alle 4 Strategien)

1. **Neues öffentliches Repo** `gtaa-dashboard`, `index.html` + README hochladen.
2. `USER = "Sin3qz"` ist **schon gesetzt**. Die vier Roh-URLs bauen sich daraus:
   `1xgtaa-signalbot/…` · `levgtaa-signalbot/…` · `reversegtaa-signalbot/…` ·
   `levspybits-signalbot/letsgo_status.json` (+ History). **Falls dein levSpyBits-Repo noch
   `letsgo-signalbot` heißt**, die Zeile im `SOURCES`-Block anpassen (oder Repo umbenennen).
3. **GitHub Pages**: Settings → Pages → „Deploy from a branch" → `main` / root → Save.

**Neu/überarbeitet im Dashboard:**
- Assets **sortiert nach dem rangbestimmenden Baustein**, der immer **links** steht: 1x/levGTAA nach
  **Momentum** (absteigend, Platz 1 oben), reverse-GTAA nach **SMA110/175-Rang** (**absteigend**: Platz 1 = höchster SMA oben,
  die gehaltenen **flop2** unten).
- **SMA-Spalten = absolute %-Werte**, grün (positiv) / rot (negativ) — keine Haken/Striche.
- **Strategie-spezifische Überschriften:** 1x/lev „Momentum (1369M)" + „SMA8/150"; reverse
  „SMA110/175-Rang" + „Trend (123M)"; levSpyBits „Trend (SMA160)" + „ΔSMA" (S&P 500 / US-TIPS).
- **levGTAA** zeigt **BTC** und die **Äquivola-Hebel mit 1 Nachkommastelle** bei den Top-2-Invest-Assets
  (z.B. TLT 4,5x, Gold 3,5x, WTI 1,7x, EM 2,4x, QQQ 3x, BTC 1x). reverse-Bug behoben (jetzt SMA110/175 + 123M).
- **reverse-GTAA:** angezeigte Allokation = Entscheidung des **Monatsletzten** (ntfy zusätzlich am 1. Tag).
- **Zeilen aller 3 GTAA-Karten auf gleicher Höhe** (Rebalancing/Stand/Baustein-Kopf); die
  **Verlaufsbalken** unten sind beschriftet (Farbe = gehaltenes Top-Asset je Zeitpunkt, grau = Cash).

---

## D) ntfy — 3 separate Topics (Handy-Push an Signal-/Monatstagen)

1. **ntfy-App** (Android/iOS) oder ntfy.sh im Browser.
2. **Drei eigene, lange Topics** (Passwortcharakter), je einen pro Bot; alle drei abonnieren.
3. Denselben Namen als `NTFY_TOPIC`-Secret im passenden Repo (A.3).

**Wann kommt ein ntfy?**
- **1xGTAA**: nur bei echtem Wechsel (Cooldown-Modell). Sonst kein ntfy.
- **levGTAA**: **jeden 1. Handelstag** des Monats — *immer*, auch ohne Wechsel („KEINE ÄNDERUNG" +
  aktuelle Top-2 mit %; Bezug = 1. Handelstag Vormonat).
- **reverse-GTAA**: **zwei** ntfy pro Monat — am **Monatsletzten** *und* am **1. Handelstag** des
  Folgemonats. Jeder Push nennt **die Entscheidung für genau diesen Tag** und die Änderung zum
  **gleichen Tagestyp im Vormonat** — so wählst du den Ausführungstag selbst. Mid-Month kein ntfy.

(Technisch: `NTFY_MODE="monthly"` + `NOTIFY_DAYS`; die Monatstage werden **kalendergenau** via
`pandas_market_calendars`/XNYS bestimmt. **1. Handelstag, nicht 1. Kalendertag** — der 1. Kalendertag
ist oft Wochenende/Feiertag ohne Schlusskurs.)

---

## E) levSpyBits (vormals SpyTips) — nur EINE Datei ersetzen

Final **75 % 3x-S&P500 + 25 % 1x-BTC, BTC nur im Markt-Regime** (kein Buy&Hold). Nur zwei Zahlen ändern:

> `bots/levspybits-signalbot-UPDATE/strategies/constants.py` → **ersetzt** deine
> `strategies/constants.py` (SPY3X_WEIGHT 0.70→**0.75**, BTC_WEIGHT 0.30→**0.25**; Kommentar auf
> levSpyBits umbenannt). Sonst nichts. Wenn du magst, benenne das Repo in **`levspybits-signalbot`**
> um (passt zur Dashboard-Quelle).

**BTC nur im Markt-Regime (bestätigt):** Markt (S&P>SMA160 **und** TIPS>SMA160) → 75 % 3xSPY + 25 % BTC;
sonst 100 % Cash. Der Bot meldet nur MARKT/CASH; die 25%-BTC-Beimischung führst du im Markt-Regime aus.

---

## E2) Welche Datei muss ich in welchem Repo ersetzen?

- **1xgtaa / levgtaa / reversegtaa** (Neu-Repos): **alle** Dateien aus dem jeweiligen Ordner hochladen
  (Erstbefüllung). Bei einem **Update später** genügen `strategies/constants.py`,
  `strategies/runner.py`, `strategies/gtaa_botcore.py` (die Infrastruktur main/send_ntfy/workflow ändert sich nicht).
- **levSpyBits** (Bestand): **nur** `strategies/constants.py` ersetzen. Rest bleibt.
- **Dashboard**: `index.html` (+ README) — `USER="Sin3qz"` ist schon gesetzt.

---

## E3) Signal-Timing — kommt das Signal vom Vortag? (Frage deines Kollegen)

**Der Live-Bot handelt mit einem Tag Versatz.** Er läuft 07:17 Berlin, sieht den **Schlusskurs des
Vortages** (US-Börse schließt nachts) und meldet darauf. Signal- und Handelstag fallen **nicht**
zusammen — das Signal stammt vom letzten verfügbaren Schlusskurs (Vortag). Beide Konventionen
gegengerechnet (beide **look-ahead-frei**):
- **A (Backtest):** Signal am Schlusskurs von Tag D, Position ab D.
- **B (realer Bot):** Signal vom Vortages-Close, Ausführung am Folgetag (1 Tag Lag).

Kosten des Lags A→B: **1xGTAA** ~−0,6 pp CAGR · **levGTAA** ~−1,0 pp · **reverse** ≈ neutral. Details je Strategie in den PDFs.
Minimal und **kein** Look-Ahead. Die Live-Performance entspricht Spalte B. Details in den PDFs (Seite „Signal-Timing").

---

## F) Deine To-do-Checkliste (kompakt)

- [ ] 3 Bot-Repos (public) anlegen, Dateien am exakten Pfad hochladen.
- [ ] 3 Discord-Kanäle + Webhooks; je URL als `DISCORD_WEBHOOK_URL` ins passende Repo.
- [ ] 3 ntfy-Topics wählen, in der App abonnieren, je als `NTFY_TOPIC` ins passende Repo.
- [ ] Pro Repo: **Workflow permissions = Read and write** (B8).
- [ ] Pro Repo: Actions aktivieren → „Run workflow" testen (erwartet: Status-Nachricht, kein Fehl-BUY).
- [ ] **60-Tage-Falle** absichern — **Schritt-für-Schritt in `GitHub_Schedule_Aktivhalten.md`** (PAT = sauberste Lösung, Keepalive = Alternative).
- [ ] Dashboard-Repo anlegen, GitHub Pages aktivieren (`USER="Sin3qz"` ist gesetzt).
- [ ] levSpyBits: `constants.py` durch das UPDATE ersetzen (75/25); optional Repo umbenennen.
- [ ] **BTC-1x-Produkt** für levGTAA besorgen und die **ISINs der 3x-EM/3x-TLT-Produkte** verifizieren (s. „Offene Punkte").

**Bereits erledigt/entschieden (kein To-do):**
- **levGTAA: Äquivola-Invest-Hebel** (QQQ 3,0x · EuroStoxx50 2,6x · EM 2,4x · **TLT 4,5x · Gold 3,5x** ·
  WTI 1,7x · **BTC 1,0x**). BTC ist ein **normales Asset** (1369M-Ranking, SMA8/150-Trend, Signal+Invest 1x).
  Alle Signale (Momentum/SMA) auf 1x-Kursen. Äquivola-Hebel (Vola-Parität zu 3x-QQQ) hebt Sortino 1,38→**1,43**.
- **reverse-GTAA: Korb QQQ/EM/Gold, fest 3x-Invest / 1x-Signal.** Unbiased optimiert (große SMA-Heatmaps,
  Rebound-Exploration, Tilt-Sweep, Fallback-Varianten, Anti-Overfit): **SMA 110/175**, **Rebound 123M**,
  **Tilt 30/70** (schwächstes 30 %, 2.-schwächstes 70 %), **Fallback slotfloor** (nur 1 Asset → max(Slot,0,5)).
  Ergebnis 35,7 / 1,11 / −44,4 / mm5 0,91. Details + alle Heatmaps in der reverse-PDF (18 Seiten).
- **Fallback (unbiased je Strategie geprüft):** 1xGTAA **Slot-Gate** (bester Drawdown); levGTAA **halfcash**
  (1 Asset→50 %+Cash — schlägt slotgate/slotfloor: ein einzelnes 67 %-Hebel-Asset ist zu konzentriert);
  reverse **slotfloor** (max(Slot,0,5) — bestes Sortino/mm5 bei reasonable Turnover). Der Hybrid „33→50, 67→behalten"
  wurde getestet, gewinnt aber bei keiner Strategie.
- **Signale = exakte Assets in USD** (kein Proxy). EMU_VALUE = Amundi (`AW1T.DE`)×`EURUSD`.
- **1. Handelstag statt 1. Kalendertag** (Handelskalender, exakt reproduzierbar).
- **ntfy braucht kein eigenes Repo:** `send_ntfy.py` liegt in jedem Bot-Repo.

---

## G) Offene Punkte (geklärt)

1. **BTC-Signal = `BTC-USD` ✓** (steht so im Code). Das konkrete 1x-BTC-Investprodukt suchst du später aus.
2. **ETF-Namen/ISINs** erscheinen ohnehin **nicht** in Discord/Dashboard/ntfy — sie stehen nur in der
   Produkt-Seite der PDFs. Für 3x-EM/3x-TLT sind dort Platzhalter (nicht erfunden); für den Bot egal.
3. **Gold-Hebel levGTAA = 3x ✓** (deine Wahl; Aequivola-Ziel war ~3). Kostet ggü. 2x etwas MaxDD
   (−53 statt −49) für +1pp CAGR. Im Dashboard/Discord wird der Hebel je Baustein angezeigt (3x/2x/1x).
4. **reverse Ausführungstage ✓:** Dashboard/Status = Monatsletzter, ntfy an **beiden** Tagen
   (Monatsletzter + 1. Handelstag) mit je eigener Entscheidung. Du wählst je Monat.

Ich habe alles gegengeprüft (Bot-Engine == verifizierter v6-Backtest, 0 Abweichung auf 5517
Handelstagen; Look-Ahead-frei; FX/Feiertags-Logik getestet; Dashboard headless gerendert). Bei Fragen
oder wenn ein Lauf rot wird: Log posten, ich schaue drauf. **KEINE ANLAGEBERATUNG.**
